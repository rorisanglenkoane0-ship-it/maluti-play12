# Maluti Play - BIWD1110 Group Assignment

A streaming platform **run entirely by its administrator**. The site starts EMPTY: the admin uploads every movie, series, reel and poster, chooses what is Featured / Trending / New / Recommended / Reel, and approves members. Plain HTML/CSS/JS + Bootstrap (CDN), no build step.

## Run
- VS Code: install **Live Server**, right-click index.html > Open with Live Server.
- Or in this folder: `python -m http.server 8000` then open http://localhost:8000

## Logins
Open **Account** in the menu. There are two tabs:

| Tab | Username | Password |
|---|---|---|
| Administrator | `admin` | `maluti2026` |
| Member | `lerato` (or `lerato@maluti.ls`) | `lerato123` |

Other people sign up on the Member tab and wait for the administrator to approve them. Passwords are only stored as salted hashes in the code, never as plain text. The administrator can change the admin password in Admin Panel > Settings. Delete this section of the README if you do not want the logins written down in the ZIP.

Admin Panel tabs:
1. **Approvals** - approve or reject people who signed up.
2. **Members** - add, suspend, remove members.
3. **Catalogue** - every title with on/off buttons for Featured, Trending, New, Recommended, Reel; Edit, Delete; Export / Import catalogue.
4. **Add Title** - title, type (Film / Series / Short), genre, year, duration, description; tick where it shows on the Discover page; upload a poster and video file or paste links; series episodes; allow member downloads.
5. **Messages** - messages sent from the About & Help contact form.
6. **Settings** - platform name, tagline, change password.

## What visitors and members see
- **Discover:** Featured banner + Trending Now, New Releases, Recommended and Reels rows. A row only appears when the admin has put something in it.
- **Browse:** all titles with search, genre, type and sort.
- **Reels:** every title the admin marked as a Reel.
- **Visitor:** can browse and read details. **Member (approved by admin):** can also watch and download what the admin allows. Members cannot change anything.

## Catalogue (already loaded)
`data/titles.json` already contains the titles the group has added so far (with posters in `images/posters/`). Every visitor sees them on the hosted site with no extra steps. Each title is also shown on the Discover page according to its Featured / Trending / New / Recommended / Reel setting.

To add more titles later you can either:
- **Send them to the developer** (poster + name + link), who adds them to `data/titles.json` and `images/posters/`, or
- **Add them yourself** in the Admin Panel, then Catalogue > Export catalogue, and replace `data/titles.json` with the downloaded file (copy any new poster images into `images/posters/`).

Uploaded video FILES stay only in the admin's browser; use links for anything that must show on the hosted site. Aim for 12+ titles in 3+ genres before submitting.

## Banner video
A short looping video (`videos/maluti-banner.mp4`, about 1 MB, no sound) plays behind the banner at the top of every page: a slow drift over the group's snowy Maluti photo with mist, falling snow and a sweep of light. It was made for this project from that photo. If the browser blocks autoplay, the user has "reduce motion" switched on, or data saver is on, the still photo is shown instead.

## Files
index.html, css/style.css, js/app.js, js/fallback-data.js, data/titles.json (starts as `[]`), images/ (logo.png, favicon.png, background.jpg).

## Credits
Bootstrap 5.3.3 (MIT). Layout style inspired by the Lesotho Library Community project. Logo and banner photos supplied by the group.
